# My Package
This package is my first attempt to building python package. The python package has a function for evaluating a list or array object and returning n number of items sorted in descending order.

## Installation Requirements
This package is available for beginners learning python and requires the following python setup:
- python text editor such as Vscode.
- latest python version.
- numpy package

## Details
The following include the package files with a short description:
- myModule.py  >>> Python function to evaluate and return top n numbers in descending order.
